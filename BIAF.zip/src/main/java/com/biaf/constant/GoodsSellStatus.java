package com.biaf.constant;

public enum GoodsSellStatus {
	SELL,SOLD_OUT
}
